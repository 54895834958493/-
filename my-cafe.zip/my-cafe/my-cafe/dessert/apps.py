from django.apps import AppConfig


class DessertConfig(AppConfig):
    name = 'dessert'
    verbose_name = 'Вкусные десерты'

