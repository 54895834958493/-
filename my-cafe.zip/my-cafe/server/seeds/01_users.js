const bcrypt = require('bcrypt'); 

exports.seed = async (knex) => {
  const password = await bcrypt.hash('74112021', 10); 

  return knex('users').del()
    .then(() => {
      return knex('users').insert([
        { name: 'Anna', email: 'qazwsx197709@gmail.com', password },
      ]);
    });
};